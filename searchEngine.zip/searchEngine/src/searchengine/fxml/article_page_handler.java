package searchengine;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

public class article_page_handler implements Initializable{

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
    }
    
}
